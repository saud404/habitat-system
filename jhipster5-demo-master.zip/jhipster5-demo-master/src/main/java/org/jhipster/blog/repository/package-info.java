/**
 * Spring Data JPA repositories.
 */
package org.jhipster.blog.repository;
