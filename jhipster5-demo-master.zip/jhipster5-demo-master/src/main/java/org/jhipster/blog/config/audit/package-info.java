/**
 * Audit specific code.
 */
package org.jhipster.blog.config.audit;
