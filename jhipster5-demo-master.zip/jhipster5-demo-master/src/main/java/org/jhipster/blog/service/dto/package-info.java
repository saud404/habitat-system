/**
 * Data Transfer Objects.
 */
package org.jhipster.blog.service.dto;
