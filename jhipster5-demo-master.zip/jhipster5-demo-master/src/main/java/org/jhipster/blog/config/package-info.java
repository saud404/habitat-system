/**
 * Spring Framework configuration files.
 */
package org.jhipster.blog.config;
