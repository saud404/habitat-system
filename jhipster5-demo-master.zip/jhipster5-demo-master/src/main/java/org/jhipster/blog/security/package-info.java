/**
 * Spring Security configuration.
 */
package org.jhipster.blog.security;
