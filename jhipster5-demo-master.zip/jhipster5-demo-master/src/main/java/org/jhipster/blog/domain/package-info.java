/**
 * JPA domain objects.
 */
package org.jhipster.blog.domain;
