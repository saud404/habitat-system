/**
 * View Models used by Spring MVC REST controllers.
 */
package org.jhipster.blog.web.rest.vm;
