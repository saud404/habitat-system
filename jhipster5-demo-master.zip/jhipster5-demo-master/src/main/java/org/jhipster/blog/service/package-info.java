/**
 * Service layer beans.
 */
package org.jhipster.blog.service;
