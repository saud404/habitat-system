export * from './tag.service';
export * from './tag-update.component';
export * from './tag-delete-dialog.component';
export * from './tag-detail.component';
export * from './tag.component';
export * from './tag.route';
